
package prog_poe;

/*import org.junit.Test;*/


public class WelcomeTest {
    
Welcome testData = new Welcome();
   String taskName1 = "Login Feature";
    String DEVELOPER_NAME1 = "Robyn C.";
    String DEVELOPER_SURNAME1 = "Harrison";
    int taskDuration1 = 8;
    String description1 = "Create Login to authenticate users";
    String taskStatus1 = "To do";

    String taskName2 = "Add Task Feature";
    String DEVELOPER_NAME2 = "Mike";
    String DEVELOPER_SURNAME2 = "Smith";
    int taskDuration2 = 10;
    String description2 = "Create Add Task feature to add task users";
    String taskStatus2 = "Doing";

   
    public void testCheckTaskDescription() {
        Welcome testData = new Welcome();
        String description1 = "Create Login to authenticate users";
        assertTrue(testData.checkTaskDescription(description1));

        String actual;
        String expected = "Task successfully captured";
        if (testData.checkTaskDescription(description1)) {
            actual = "Task successfully captured";
        } else {
            actual = "Please enter the task description. Description should not exceed 50 characters";
        }

        assertEquals(expected, actual);
    }

    
    public void testCreateTaskID() {
        Welcome testData = new Welcome();
        String taskName1 = "Login Feature";
        String DEVELOPER_NAME1 = "Robyn C.";
        int taskNumber1 = 0;
        String expected1 = "LO:0:N C.";
        String actual1 = testData.createTaskID(taskName1, taskNumber1, DEVELOPER_NAME1);
        assertEquals(expected1, actual1);

        String taskName2 = "Add Task Feature";
        String DEVELOPER_NAME2 = "Mike";
        int taskNumber2 = 1;
        String expected2 = "AD:1:KE";
        String actual2 = testData.createTaskID(taskName2, taskNumber2, DEVELOPER_NAME2);
        assertEquals(expected2, actual2);
    }

   
    public void testReturnTotalHours() {
        Welcome[] tasks = {
            new Welcome("Task 1", "Description 1", "Developer 1", 8.5, "To do"),
            new Welcome("Task 2", "Description 2", "Developer 2", 10.25, "Doing")
        };

        int expectedHours = 18;
        int actualHours = Welcome.returnTotalHours(tasks);
        assertEquals(expectedHours, actualHours);
    }

   
    public void testDisplayTotalHours() {
        // No test case provided for this method
    }

    
    public void testCheckTaskDescriptionAgain() {
        Welcome testData = new Welcome();
        String description1 = "Create Login to authenticate users";
        assertTrue(testData.checkTaskDescription(description1));

        String actual;
        String expected = "Task successfully captured";

        if (testData.checkTaskDescription(description1)) {
            actual = "Task successfully captured";
        } else {
            actual = "Please enter the task description. Description should not exceed 50 characters";
        }

        assertEquals(expected, actual);
    }

    private void assertEquals(String expected, String actual) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertTrue(boolean checkTaskDescription) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(int expectedHours, int actualHours) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

    

   

    
