package prog_poe;

import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Iterator;

public class TaskClass1 {
    private static final ArrayList<String> developers = new ArrayList<>();
    private static final ArrayList<String> taskNames = new ArrayList<>();
    private static final ArrayList<String> taskIDs = new ArrayList<>();
    private static final ArrayList<Integer> taskDurations = new ArrayList<>();
    private static final ArrayList<String> taskStatuses = new ArrayList<>();

    // Function to add a new task
    public void addTask() {
        String taskName = JOptionPane.showInputDialog("Enter the task name:");
        String developerDetails = JOptionPane.showInputDialog("Enter the developer details (Name and Surname):");
        double taskDuration = Double.parseDouble(JOptionPane.showInputDialog("Enter the task duration in hours:"));

        String[] statusOptions = {"To Do", "Done", "Doing"};
        int selectedOption = JOptionPane.showOptionDialog(
                null,
                "Select task status:",
                "Task Status",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                statusOptions,
                statusOptions[0]);

        if (selectedOption == -1) {
            JOptionPane.showMessageDialog(null, "Task status not selected. Task not added.");
            return;
        }

        String taskStatus = statusOptions[selectedOption];

        // Generate a unique task ID
        String taskID = generateUniqueTaskID(taskName, developerDetails);

        developers.add(developerDetails);
        taskNames.add(taskName);
        taskIDs.add(taskID);
        taskDurations.add((int) taskDuration);
        taskStatuses.add(taskStatus);

        JOptionPane.showMessageDialog(null, "Task successfully captured");
        JOptionPane.showMessageDialog(null, printTaskDetails(developerDetails, taskName, taskID, (int) taskDuration, taskStatus));
    }

    // Helper method to generate a unique task ID
    private String generateUniqueTaskID(String taskName, String developer) {
        String taskID = taskName.substring(0, 2) + ":" + (taskIDs.size() + 1) + ":" + developer.substring(developer.length() - 3);
        return taskID.toUpperCase();
    }

    // Helper method to print task details
    private String printTaskDetails(String developer, String taskName, String taskID, int taskDuration, String taskStatus) {
        StringBuilder sb = new StringBuilder();
        sb.append("Task Details:\n")
                .append("Developer: ").append(developer).append("\n")
                .append("Task Name: ").append(taskName).append("\n")
                .append("Task ID: ").append(taskID).append("\n")
                .append("Task Duration: ").append(taskDuration).append(" hours\n")
                .append("Task Status: ").append(taskStatus);
        return sb.toString();
    }

    // Function to display tasks with status "done"
    public void displayTasksWithStatusDone() {
        StringBuilder message = new StringBuilder("Tasks with status 'Done':\n\n");
        for (int i = 0; i < taskStatuses.size(); i++) {
            if ("Done".equals(taskStatuses.get(i))) {
                message.append("Developer: ").append(developers.get(i)).append("\n");
                message.append("Task Name: ").append(taskNames.get(i)).append("\n");
                message.append("Task Duration: ").append(taskDurations.get(i)).append(" hours\n");
                message.append("----------------------\n");
            }
        }
        JOptionPane.showMessageDialog(null, message.toString());
    }

    // Function to display the task with the longest duration
    public void displayTaskWithLongestDuration() {
        int maxDuration = 0;
        int maxDurationIndex = -1;
        for (int i = 0; i < taskDurations.size(); i++) {
            if (taskDurations.get(i) > maxDuration) {
                maxDuration = taskDurations.get(i);
                maxDurationIndex = i;
            }
        }
        if (maxDurationIndex != -1) {
            StringBuilder message = new StringBuilder("Longest Task:\n\n");
            message.append("Developer: ").append(developers.get(maxDurationIndex)).append("\n");
            message.append("Task Name: ").append(taskNames.get(maxDurationIndex)).append("\n");
            message.append("Task Duration: ").append(maxDuration).append(" hours");
            JOptionPane.showMessageDialog(null, message.toString());
        }
    }

    // Function to search for a task by name
    public void searchTaskByName(String taskName) {
        boolean found = false;
        for (int i = 0; i < taskNames.size(); i++) {
            if (taskNames.get(i).equals(taskName)) {
                JOptionPane.showMessageDialog(null, printTaskDetails(developers.get(i), taskNames.get(i), taskIDs.get(i), taskDurations.get(i), taskStatuses.get(i)));
                found = true;
                break;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "Task not found.");
        }
    }

    // Function to delete a task by name
    public void deleteTaskByName(String taskName) {
        Iterator<String> taskIterator = taskNames.iterator();
        while (taskIterator.hasNext()) {
            String name = taskIterator.next();
            if (name.equals(taskName)) {
                int index = taskNames.indexOf(name);
                taskIterator.remove();
                developers.remove(index);
                taskIDs.remove(index);
                taskDurations.remove(index);
                taskStatuses.remove(index);
                JOptionPane.showMessageDialog(null, "Task successfully deleted.");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found.");
    }

    // Function to display all tasks
    public void displayAllTasks() {
        StringBuilder message = new StringBuilder("All Tasks:\n\n");
        for (int i = 0; i < taskNames.size(); i++) {
            message.append(printTaskDetails(developers.get(i), taskNames.get(i), taskIDs.get(i), taskDurations.get(i), taskStatuses.get(i))).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, message.toString());
    }
}


