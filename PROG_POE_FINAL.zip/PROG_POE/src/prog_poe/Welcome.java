
package prog_poe;


public class Welcome {
        private static int taskCount = 1;
    private static int totalHours = 0; // New instance variable for total hours
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private double taskDuration;
    private String taskID;
    private String taskStatus;

    public Welcome() {
    }

    public Welcome(String taskName, String taskDescription, String developerDetails, double taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskCount;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskID = createTaskID(taskName, taskNumber, developerDetails);
        this.taskStatus = taskStatus;
        taskCount++;
    }

    public boolean checkTaskDescription(String description) {
        return description.length() <= 50;
    }
    public String printTaskDetails() {
         String taskDetails = "Task Name: " + taskName + "\n" +
            "Task Number: " + taskNumber + "\n" +
            "Task Description: " + taskDescription + "\n" +
            "Developer Details(Name and surname): " + developerDetails + "\n" +
            "Task Duration: " + taskDuration + "\n" +
            "Task Status: " + taskStatus + "\n" +
            "Task ID: " + taskID + "\n";

       if (taskStatus.equalsIgnoreCase("To Do") || taskStatus.equalsIgnoreCase("Done") || taskStatus.equalsIgnoreCase("Doing")) {
        Welcome[] allTasks = new Welcome[taskCount - 1]; 
        for (int i = 0; i < taskCount - 1; i++) {
            allTasks[i] = new Welcome(); 
        }

//    int totalHours = returnTotalHours(allTasks);
//     taskDetails += "Total Hours: " + totalHours+ taskDuration;
   }
  
    return taskDetails;
    }

    public String createTaskID(String taskName, int taskNumber, String developerDetails) {
        String taskNameInitials = taskName.substring(0, 2).toUpperCase();
        String developerInitials = developerDetails.substring(developerDetails.length() - 3).toUpperCase();
     return taskNameInitials + ":" + taskNumber + ":" + developerInitials;
    }


    public static int returnTotalHours(Welcome[] tasks) {
        int totalHours = 0;
        for (Welcome task : tasks) {
            totalHours += task.taskDuration;
        }
        return totalHours;
    }

    // Getters and setters for the class variables

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public int getTaskNumber() {
        return taskNumber;
    }

    public void setTaskNumber(int taskNumber) {
        this.taskNumber = taskNumber;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    public String getDeveloperDetails() {
        return developerDetails;
    }

    public void setDeveloperDetails(String developerDetails) {
        this.developerDetails = developerDetails;
    }

    public double getTaskDuration() {
        return taskDuration;
    }

    public void setTaskDuration(double taskDuration) {
        this.taskDuration = taskDuration;
    }

    public String getTaskID() {
        return taskID;
    }

    public void setTaskID(String taskID) {
        this.taskID = taskID;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

}
