
package prog_poe;

import javax.swing.JOptionPane;

public class Register {
    private String username;
    private String password;

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void checkUsername() {
        boolean valid = false;
        while (!valid) {
            username = JOptionPane.showInputDialog("Please enter a 5 character long username which contains an underscore: ").trim();
            if (username.length() == 5 && username.contains("_")) {
                JOptionPane.showMessageDialog(null, "Username successfully captured");
                valid = true;
            } else {
                JOptionPane.showMessageDialog(null, "Username format incorrect");
            }
        }
    }

    public void checkPassword() {
        boolean valid = false;
        while (!valid) {
            password = JOptionPane.showInputDialog("Please enter an 8 character password which contains a capital letter, a number, and a special character: ");
            if (password.length() >= 8 && password.matches(".*[A-Z].*") && password.matches(".*\\d.*") && password.matches(".*[^A-Za-z0-9].*")) {
                JOptionPane.showMessageDialog(null, "Password successfully captured");
                valid = true;
            } else {
                JOptionPane.showMessageDialog(null, "Password format incorrect");
            }
        }
    }
}


    

