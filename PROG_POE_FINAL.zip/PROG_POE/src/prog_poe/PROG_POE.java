
package prog_poe;

import javax.swing.JOptionPane;

public class PROG_POE {

    public static void main(String[] args) {
        // Get user's first and last name
        String firstname = JOptionPane.showInputDialog("Please enter your first name: ");
        String lastname = JOptionPane.showInputDialog("Please enter your last name: ");

        // Perform registration
        Register u = new Register();
        u.checkUsername();
        u.checkPassword();

        // Perform login
        Login l = new Login();
        l.checkLoginUsername();
        l.checkLoginPassword();

        // Retrieve registration and login details
        String regUsername = u.getUsername();
        String regPassword = u.getPassword();
        String loginUsername = l.getLoginUsername();
        String loginPassword = l.getLoginPassword();

        // Check if login details match registration details
        if (regUsername != null && regUsername.equals(loginUsername) &&
                regPassword != null && regPassword.equals(loginPassword)) {
            JOptionPane.showMessageDialog(null, "Welcome " + firstname + " " + lastname + "\n It's great to see you again");
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

            // Initialize TaskClass1 instance
            TaskClass1 taskManager = new TaskClass1();

            // Task management loop
            int choice;
            do {
                String choiceString = JOptionPane.showInputDialog(null, """
                                                                         Choose an option:
                                                                         1) Add tasks
                                                                         2) Show report
                                                                         3) Quit""");

                choice = Integer.parseInt(choiceString);

                switch (choice) {
                    case 1:
                        taskManager.addTask(); // Add a task using TaskClass1 method
                        break;
                    case 2:
                        taskManager.displayAllTasks(); // Display all tasks using TaskClass1 method
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(null, "Exiting EasyKanban");
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
                        break;
                }
            } while (choice != 3);
            JOptionPane.showMessageDialog(null, "Thanks for using this application");

        } else {
            JOptionPane.showMessageDialog(null, "Username or password incorrect, please try again");
        }
    }
}






