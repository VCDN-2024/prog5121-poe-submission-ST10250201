package prog_poe;

public class TaskClass1Test {

    public static void main(String[] args) {
        TaskClass1 taskManager = new TaskClass1();

        // Add some tasks for testing
        taskManager.addTask();
        taskManager.addTask();
        taskManager.addTask();

        // Display all tasks
        taskManager.displayAllTasks();

        // Display tasks with status "done"
        taskManager.displayTasksWithStatusDone();

        // Display task with the longest duration
        taskManager.displayTaskWithLongestDuration();

        // Search for a task by name
        taskManager.searchTaskByName("TaskName");

        // Delete a task by name
        taskManager.deleteTaskByName("TaskName");

        // Display all tasks after deletion
        taskManager.displayAllTasks();
    }
}




