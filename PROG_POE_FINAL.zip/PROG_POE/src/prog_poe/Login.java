package prog_poe;

import javax.swing.JOptionPane;

public class Login {
    private String loginUsername;
    private String loginPassword;

    public Login(String username, String password) {
        this.loginUsername = username;
        this.loginPassword = password;
    }

    public Login() {
        // Default constructor if needed
    }

    public String getLoginUsername() {
        return loginUsername;
    }

    public void setLoginUsername(String loginUsername) {
        this.loginUsername = loginUsername;
    }

    public String getLoginPassword() {
        return loginPassword;
    }

    public void setLoginPassword(String loginPassword) {
        this.loginPassword = loginPassword;
    }

    public void checkLoginUsername() {
        // Simulating username check (replace with actual logic)
        this.loginUsername = JOptionPane.showInputDialog("Enter your username: ");
    }

    public void checkLoginPassword() {
        // Simulating password check (replace with actual logic)
        this.loginPassword = JOptionPane.showInputDialog("Enter your password: ");
    }
}


